import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from sklearn.svm import SVC

# Import the dataset
df = np.loadtxt(open('data/dataset.csv','rb'), delimiter = ',')

# Splitting dataset into features and label
X = df[:, 0:5]
y = df[:, 5]

# Splitting the dataset into the training set and the test-size is 25% (0.25)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# Fitting SVM with the training set
classifier = SVC()
flow_model=classifier.fit(X_train, y_train)

# Testing the model by classifying the test set
classifier_predictions = classifier.predict(X_test)

# Calculate the Detection Ratio
print("Calculation Detection Ratio:")
length = len(y_test)

TP = 0 # True Positive
FP = 0 # False Positive
FN = 0 # False Negative 
TN = 0 # True Negative

for i in range(0,length):
    #print("Actual",y_test[i], "prediction", classifier_predictions[i])
    #Calculating DR
    if y_test[i] == 1.0:
        if classifier_predictions[i] == 1.0:
            TP = TP + 1
        else:
            FP = FP + 1
    #calculating FAR
    if y_test[i] == 0.0:
        if classifier_predictions[i] == 1.0:
            FN = FN + 1
        else:
            TN = TN + 1

DR = TP / (TP + FP)
print("Detection rate =", DR*100,'%')

ER = (FP+FN)/(TP+FN+FP+FN)
print("Error Rate =", ER*100,'%')
print("TP = ", TP)
print("FP = ", FP)
print("TN = ", TN)
print("FN = ", FN)

AC = (TP+TN)/(TP+FN+FP+TN)
print("Accuracy =", AC*100,'%')
